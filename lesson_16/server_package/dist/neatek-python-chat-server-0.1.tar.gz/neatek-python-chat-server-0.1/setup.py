from setuptools import setup, find_packages

setup(
    name="neatek-python-chat-server",
    version="0.1",
    description="Server packet",
    packages=find_packages(),
    author_email="neatek@icloud.com",
    author="Vladimir Zhelnov",
    # install_requeres=[
    #     "sqlite3",
    #     "PyQt5",
    #     "sqlalchemy",
    #     "pycruptodome",
    #     "pycryptodomex",
    # ],
)

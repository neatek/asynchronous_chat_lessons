from setuptools import setup, find_packages

setup(
    name="client_chat",
    version="0.1",
    description="Client packet",
    packages=find_packages(),
    author_email="mail@GeekBrains.ru",
    author="GeekBrains",
    install_requeres=["PyQt5", "sqlalchemy", "pycruptodome", "pycryptodomex"],
)

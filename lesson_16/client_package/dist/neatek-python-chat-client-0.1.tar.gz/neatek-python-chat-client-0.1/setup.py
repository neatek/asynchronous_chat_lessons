from setuptools import setup, find_packages

setup(
    name="neatek-python-chat-client",
    version="0.1",
    description="Client packet",
    packages=find_packages(),
    author_email="neatek@icloud.com",
    author="Vladimir Zhelnov",
    # install_requeres=["PyQt5", "sqlalchemy", "pycruptodome", "pycryptodomex"],
)
